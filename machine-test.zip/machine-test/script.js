document.getElementById("hamber-menu").addEventListener("click",function(){

    document.getElementById("menu").style.transform='translate(0%)'




})

document.getElementById("close").addEventListener("click",function(){

    document.getElementById("menu").style.transform='translate(-100%)'




})